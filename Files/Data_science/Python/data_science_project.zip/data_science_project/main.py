from src.models.operations import Operations


2

print(Operations.calculate_average([4,1,3]))


