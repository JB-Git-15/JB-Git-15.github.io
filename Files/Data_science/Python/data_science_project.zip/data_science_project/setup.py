from setuptools import setup, find_packages


setup(
    name="package_data_science_project",
    version="0.1.0",
    description="Test package",
    author="JB",
    author_email="your_email@example.com",
    packages=find_packages(),
    install_requires=["numpy"]
)